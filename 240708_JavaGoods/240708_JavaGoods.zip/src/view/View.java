package view;

public enum View {
	MAIN,					// 기본화면
	GOODS_LIST,
	GOODS_DETAIL,
	GOODS_UPDATE,
	GOODS_DELETE,
	GOODS_INSERT
}
