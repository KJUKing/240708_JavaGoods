package defaultPaging;

public class PagingTest {
    public static void main(String[] args) {

        int pageNo = 1;

        int pageSize = 5;
        int startNo = 1 + 5 * (pageNo - 1);
        int endNo = 5 * pageNo;
    }
}
